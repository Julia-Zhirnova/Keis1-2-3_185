﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using ClassLibrary;

namespace ConsoleAppCode
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(vsscodde.GetStudNumber("Иванов Иван Иванович", DateTime.Now, Convert.ToInt32("12")));
            
            Assembly a = Assembly.Load("ClassLibraryCode");
            Object o = a.CreateInstance("ClassLibrary.vsscodde"); 
            Type t = a.GetType("ClassLibrary.vsscodde");
            Object[] numbers = new Object[2];
            numbers[0] = 1;
            numbers[1] = 5;
            MethodInfo mi = t.GetMethod("add");
            Console.WriteLine(mi.Invoke(o, numbers));
            Console.ReadLine();
        }
    }
}
